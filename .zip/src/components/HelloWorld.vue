<script setup lang="ts">
import { reactive, ref } from "vue";
import { Nodes, Edges } from "v-network-graph";
import data from "./data";

var nodes: Nodes = reactive({ ...data.nodes });
var edges: Edges = reactive({ ...data.edges });
var nextNodeIndex = ref(Object.keys(nodes).length + 1);
var nextEdgeIndex = ref(Object.keys(edges).length + 1);

var selectedNodes = ref<string[]>([]);
var selectedEdges = ref<string[]>([]);

function addNode() {
  var nodeId = `node${nextNodeIndex.value}`;
  var name = `N${nextNodeIndex.value}`;
  nodes[nodeId] = { name };
  nextNodeIndex.value++;
}

function removeNode() {
  for (const nodeId of selectedNodes.value) {
    delete nodes[nodeId];
  }
}

function addEdge() {
  if (selectedNodes.value.length !== 2) return;
  const [source, target] = selectedNodes.value;
  const edgeId = `edge${nextEdgeIndex.value}`;
  edges[edgeId] = { source, target };
  nextEdgeIndex.value++;
}

function removeEdge() {
  for (const edgeId of selectedEdges.value) {
    delete edges[edgeId];
  }
}
</script>

<template>
  <div class="demo-control-panel">
    <div>
      <label>Node:</label>
      <button @click="addNode">add</button>
      <button :disabled="selectedNodes.length == 0" @click="removeNode">
        remove
      </button>
    </div>
    <div>
      <label>Edge:</label>
      <button :disabled="selectedNodes.length != 2" @click="addEdge">
        add
      </button>
      <button :disabled="selectedEdges.length == 0" @click="removeEdge">
        remove
      </button>
    </div>
  </div>

  <div class="networkWindow">
    <div class="grid-item-path">penis</div>
    <v-network-graph
      class="grid-item-network"
      v-model:selected-nodes="selectedNodes"
      v-model:selected-edges="selectedEdges"
      :nodes="nodes"
      :edges="edges"
      :layouts="data.layouts"
      :configs="data.configs"
    />
    <div class="grid-item-structure">nepenis</div>
  </div>
</template>

<style>
.networkWindow {
  background-color: white;
  display: grid;
  grid-template-columns: 2fr 10fr 4fr;
  grid-template-areas: "path network structure";
}
.grid-item-path {
  grid-area: path;
  background-color: brown;
}

.grid-item-network {
  grid-area: network;
}

.grid-item-structure {
  grid-area: structure;
  background-color: aqua;
}
</style>