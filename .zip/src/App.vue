<template>
  <div class="mainWindow">
    <Header />
    <HelloWorld msg="Welcome to Your Vue.js App" class="mojeee" />
    <div>p</div>
    <footer>
      <span>Tato praca vznikla ako bakalarska praca</span>
    </footer>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld.vue";

export default {
  name: "App",
  components: {
    HelloWorld,
  },
};
</script>

<style>
.mojeee {
  height: 60vh !important;
}
.mainWindow {
  background-color: chartreuse;
  height: 100vh;
  padding: 20px;
  margin: 0;
}
</style>
